public interface Employer {

    public String affiche();
    public int compare();
    
}